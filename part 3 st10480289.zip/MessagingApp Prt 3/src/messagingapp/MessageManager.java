/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package messagingapp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ebby
 */
public class MessageManager {
    
    private ArrayList<Message> sentMessages;
    private ArrayList<Message> disregardedMessages;
    private ArrayList<Message> storedMessages;
    private ArrayList<String> messageHashes;
    private ArrayList<String> messageIDs;

    public MessageManager() {
        sentMessages = new ArrayList<>();
        disregardedMessages = new ArrayList<>();
        storedMessages = new ArrayList<>();
        messageHashes = new ArrayList<>();
        messageIDs = new ArrayList<>();
    }

    public void addMessage(Message message) {
        switch(message.getFlag().toLowerCase()) {
            case "sent":
                sentMessages.add(message);
                break;
            case "stored":
                storedMessages.add(message);
                break;
            case "disregard":
                disregardedMessages.add(message);
                break;
        }
        messageHashes.add(message.getHash());
        messageIDs.add(message.getMessageID());
    }

    
    public void displaySentMessagesSenders() {
        System.out.println("\n--- Sent Messages Senders & Recipients ---");
        for (Message msg : sentMessages) {
            System.out.println("Recipient: " + msg.getRecipient());
        }
    }

    
    public void displayLongestSentMessage() {
        if (sentMessages.isEmpty()) {
            System.out.println("No sent messages available.");
            return;
        }
        
        Message longest = sentMessages.get(0);
        for (Message msg : sentMessages) {
            if (msg.getContent().length() > longest.getContent().length()) {
                longest = msg;
            }
        }
        
        System.out.println("\n--- Longest Sent Message ---");
        System.out.println(longest);
    }

   
    public void searchByMessageID(String messageID) {
        for (Message msg : sentMessages) {
            if (msg.getMessageID().equals(messageID)) {
                System.out.println("\n--- Message Found ---");
                System.out.println("Recipient: " + msg.getRecipient());
                System.out.println("Content: " + msg.getContent());
                return;
            }
        }
        System.out.println("Message with ID " + messageID + " not found in sent messages.");
    }

    
    public void searchByRecipient(String recipient) {
        System.out.println("\n--- Messages to " + recipient + " ---");
        boolean found = false;
        
        for (Message msg : sentMessages) {
            if (msg.getRecipient().equals(recipient)) {
                System.out.println(msg);
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    
    public boolean deleteMessageByHash(String hash) {
        for (Message msg : sentMessages) {
            if (msg.getHash().equals(hash)) {
                sentMessages.remove(msg);
                messageHashes.remove(hash);
                messageIDs.remove(msg.getMessageID());
                return true;
            }
        }
        return false;
    }

   
    public void displayFullReport() {
        System.out.println("\n--- Full Sent Messages Report ---");
        for (Message msg : sentMessages) {
            System.out.println(msg);
        }
    }}
    

    
