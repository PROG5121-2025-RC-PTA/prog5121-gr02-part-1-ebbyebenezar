/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package messagingapp;
import java.util.Scanner;

/**
 *
 * @author Ebby
 */
public class MessagingApp {

    
    public static void main(String[] args) {
        
        
        MessageManager manager = new MessageManager();
        Scanner scanner = new Scanner(System.in);
        
        initializeTestData(manager);
        
        // Menu system
        boolean running = true;
        while (running) {
            System.out.println("\n=== Messaging Application ===");
            System.out.println("1. Display sender/recipient of all sent messages");
            System.out.println("2. Display longest sent message");
            System.out.println("3. Search message by ID");
            System.out.println("4. Search messages by recipient");
            System.out.println("5. Delete message by hash");
            System.out.println("6. Display full report");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (choice) {
                case 1:
                    manager.displaySentMessagesSenders();
                    break;
                case 2:
                    manager.displayLongestSentMessage();
                    break;
                case 3:
                    System.out.print("Enter message ID to search: ");
                    String searchID = scanner.nextLine();
                    manager.searchByMessageID(searchID);
                    break;
                case 4:
                    System.out.print("Enter recipient number to search: ");
                    String recipient = scanner.nextLine();
                    manager.searchByRecipient(recipient);
                    break;
                case 5:
                    System.out.print("Enter message hash to delete: ");
                    String hash = scanner.nextLine();
                    if (manager.deleteMessageByHash(hash)) {
                        System.out.println("Message deleted successfully.");
                    } else {
                        System.out.println("Message not found.");
                    }
                    break;
                case 6:
                    manager.displayFullReport();
                    break;
                case 7:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
        
        scanner.close();
        System.out.println("Application exited.");
    }
    
    private static void initializeTestData(MessageManager manager) {
        manager.addMessage(new Message("1", "+27834557896", "Did you get the cake?", "Sent"));
        manager.addMessage(new Message("2", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored"));
        manager.addMessage(new Message("3", "+27834484567", "Yohoooo, I am at your gate.", "Disregard"));
        manager.addMessage(new Message("4", "0838884567", "It is dinner time", "Sent"));
        manager.addMessage(new Message("5", "+27838884567", "Ok, I am leaving without you", "Stored"));
    }
}
    
    

