/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package messagingapp;

/**
 *
 * @author Ebby
 */
public class Message {
    
    private String messageID;
    private String recipient;
    private String content;
    private String flag; 
    private String hash;

    public Message(String messageID, String recipient, String content, String flag) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.content = content;
        this.flag = flag;
        this.hash = generateHash();
    }

    private String generateHash() {
       
        return Integer.toString((messageID + recipient + content).hashCode());
    }

    
    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }
    public String getFlag() { return flag; }
    public String getHash() { return hash; }

    @Override
    public String toString() {
        return "ID: " + messageID + "\nRecipient: " + recipient + 
               "\nContent: " + content + "\nStatus: " + flag + "\nHash: " + hash + "\n";
    }
}
    

