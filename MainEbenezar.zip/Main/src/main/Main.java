/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;
import java.util.*;
/**
 *
 * @author Ebby
 */
public class Main {

    
    public static void main(String[] args) {
        
     Scanner sc = new Scanner(System.in);

System.out.print("Enter First Name: ");
    String firstName = sc.nextLine();
    System.out.print("Enter Last Name: ");
    String lastName = sc.nextLine();
    System.out.print("Enter Username: ");
    String username = sc.nextLine();
    System.out.print("Enter Password: ");
    String password = sc.nextLine();
    System.out.print("Enter Cell Number (+27...): ");
    String cell = sc.nextLine();

    Login login = new Login(firstName, lastName, username, password, cell);
    System.out.println(login.registerUser());

    System.out.print("Login Username: ");
    String inputUser = sc.nextLine();
    System.out.print("Login Password: ");
    String inputPass = sc.nextLine();

    boolean success = login.loginUser(inputUser, inputPass);
    System.out.println(login.returnLoginStatus(success));

    if (!success) return;

    MessageManager mm = new MessageManager();
    System.out.println("Welcome to QuickChat");

    while (true) {
        System.out.println("\n1) Send Message\n2) Show Recently Sent Messages\n3) Quit");
        int choice = sc.nextInt(); sc.nextLine();
        if (choice == 3) break;
        switch (choice) {
            case 1 -> {
                System.out.print("How many messages would you like to send? ");
                int count = sc.nextInt(); sc.nextLine();
                for (int i = 0; i < count; i++) {
                    System.out.print("Enter Message ID: ");
                    String id = sc.nextLine();
                    System.out.print("Enter Recipient Cell: ");
                    String recipient = sc.nextLine();
                    System.out.print("Enter Message: ");
                    String msg = sc.nextLine();
                    System.out.println(mm.sendMessage(recipient, msg, id, i + 1));
                }
                System.out.println("Total Messages Sent: " + mm.returnTotalMessages());
            }
            case 2 -> System.out.println("Coming Soon.");
            default -> System.out.println("Invalid option.");
        }
    }
    mm.storeMessagesToFile();
}

}