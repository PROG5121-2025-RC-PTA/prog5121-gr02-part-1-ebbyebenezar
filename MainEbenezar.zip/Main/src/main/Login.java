/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author Ebby
 */
public class Login {
    
    private final String username; 
    private final String password; 
    private final String cellNumber; 
    private final String firstName; 
    private final String lastName;

public Login(String firstName, String lastName, String username, String password, String cellNumber) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.username = username;
    this.password = password;
    this.cellNumber = cellNumber;
}

public boolean checkUserName() {
    return username.contains("_") && username.length() <= 5;
}

public boolean checkPasswordComplexity(String password) {
    // At least 8 characters, one capital letter, one number, one special character
    String pattern = "^(?=.[A-Z])(?=.\\d)(?=.*[@#$%^&+=!]).{8,}$";
    return password.matches(pattern);
}
public boolean checkCellPhoneNumber() {
    return cellNumber.matches("^\\+27\\d{9}$");
}

public String registerUser() {
    if (!checkUserName()) return "Username is not correctly formatted...";
    if (checkPasswordComplexity("Ch&&sec@ke99!")) {
        } else {
        return "Password is not correctly formatted...";
        }
    if (!checkCellPhoneNumber()) return "Cell phone number incorrectly formatted...";
    return "User registered successfully.";
}

public boolean loginUser(String inputUsername, String inputPassword) {
    return inputUsername.equals(username) && inputPassword.equals(password);
}

public String returnLoginStatus(boolean success) {
    return success ? "Welcome " + firstName + ", " + lastName + " it is great to see you again." :
            "Username or password incorrect, please try again.";
}

}


    

