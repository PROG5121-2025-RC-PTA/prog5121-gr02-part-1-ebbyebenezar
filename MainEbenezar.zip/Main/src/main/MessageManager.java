/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import java.io.FileWriter; 
import java.util.*;

/**
 *
 * @author Ebby
 */
public class MessageManager {
    
    private final List<String> messages =new ArrayList<>(); 
    private int totalMessages = 0;

public boolean checkMessageId(String messageId) {
    return messageId.length() <= 10;
}

public boolean checkRecipientCell(String recipientCell) {
    return recipientCell.matches("^\\+27\\d{9}$");
}

public String createMessageHash(String messageId, int messageNumber, String messageText) {
    String[] words = messageText.split(" ");
    String firstWord = words[0].toUpperCase();
    String lastWord = words[words.length - 1].toUpperCase();
    return messageId.substring(0, 2) + ":" + messageNumber + ":" + firstWord + lastWord;
}

public String sendMessage(String recipient, String message, String messageId, int messageNumber) {
    if (!checkMessageId(messageId)) return "Invalid Message ID.";
    if (!checkRecipientCell(recipient)) return "Invalid Recipient Cell Number.";
    if (message.length() > 250) return "Please enter a message of less than 250 characters";

    String messageHash = createMessageHash(messageId, messageNumber, message);
    String fullMessage = "MessageID: " + messageId +
            "\nMessage Hash: " + messageHash +
            "\nRecipient: " + recipient +
            "\nMessage: " + message;
    messages.add(fullMessage);
    totalMessages++;
    return "Message sent\n" + fullMessage;
}

public int returnTotalMessages() {
    return totalMessages;
}

public String printMessages() {
    return String.join("\n---\n", messages);
}

public void storeMessagesToFile() {
    JSONArray jsonMessages = new JSONArray();
    for (String msg : messages) {
        JSONObject obj = new JSONObject();
        obj.put("message", msg);
        jsonMessages.add(obj);
    }
    try (FileWriter file = new FileWriter("messages.json")) {
        file.write(jsonMessages.toJSONString());
    } catch (Exception e) {
    }
}

    private static class JSONArray {

        public JSONArray() {
        }


        private char[] toJSONString() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        private void add(JSONObject obj) {
            throw new UnsupportedOperationException("Not supported yet."); 
        }
    }

    private static class JSONObject {

        public JSONObject() {
        }

        private void put(String message, String msg) {
            throw new UnsupportedOperationException("Not supported yet."); 
        }

    }

}

    

